# PixelOS

PixelOS (già KairoOS, nome dev: AnimateOS/Viteza) — sistema operativo hobby x86-64
con kernel scritto in C e Assembly. Boot **Multiboot2/PVH**, GUI proprietaria con
rendering 3D software, tema scuro.

## Requisiti
- QEMU (`brew install qemu` su macOS, `apt install qemu-system-x86` su Linux/Windows WSL)
- Mac: tasto destro non serve, si avvia tutto da terminale

## Avvio da ISO
```sh
./run-pixelos.sh iso
```
Avvio rapido via kernel (più veloce):
```sh
./run-pixelos.sh kernel
```

## Avvio manuale
```sh
qemu-system-x86_64 -cdrom PixelOS.iso -m 256 -vga std -machine pc,accel=tcg -cpu qemu64 -display sdl
```
