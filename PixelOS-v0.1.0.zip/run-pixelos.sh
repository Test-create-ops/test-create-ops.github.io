#!/bin/sh
# Lancia PixelOS in QEMU
# Uso: ./run-pixelos.sh [iso|kernel]
set -e
cd "$(dirname "$0")"
case "${1:-iso}" in
  iso)
    exec qemu-system-x86_64 -cdrom PixelOS.iso -m 256 -vga std \
         -machine pc,accel=tcg -cpu qemu64 -display sdl
    ;;
  kernel)
    exec qemu-system-x86_64 -kernel kernel.bin -m 256 -vga std \
         -machine pc,accel=tcg -cpu qemu64 -display sdl
    ;;
  *) echo "uso: $0 [iso|kernel]"; exit 1 ;;
esac
